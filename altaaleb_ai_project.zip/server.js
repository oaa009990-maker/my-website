import express from "express";
import rateLimit from "express-rate-limit";
import OpenAI from "openai";
import path from "path";
import { fileURLToPath } from "url";

const app = express();
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const port = process.env.PORT || 3000;

app.use(express.json({ limit: "20kb" }));
app.use(express.static(path.join(__dirname, "public")));
app.use("/api/ask", rateLimit({ windowMs: 60 * 1000, limit: 12, standardHeaders: true, legacyHeaders: false }));

app.post("/api/ask", async (req, res) => {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    return res.status(503).json({
      error: "لسه مفتاح الذكاء الاصطناعي مش متضاف على الخادم. أضف OPENAI_API_KEY في Secrets/Environment Variables."
    });
  }

  const { stage, grade, subject, lesson, question, history = [] } = req.body || {};
  if (!question || typeof question !== "string" || question.trim().length > 3000) {
    return res.status(400).json({ error: "اكتب سؤالك في حدود 3000 حرف." });
  }

  try {
    const client = new OpenAI({ apiKey });
    const safeHistory = Array.isArray(history)
      ? history.slice(-8).filter(m => ["user", "assistant"].includes(m.role) && typeof m.content === "string")
        .map(m => ({ role: m.role, content: m.content.slice(0, 3000) }))
      : [];

    const context = `أنت المعلم الذكي في موقع الطالب، مساعد تعليمي باللغة العربية للطلاب في مصر.
اشرح بلغة عربية بسيطة مناسبة لعمر الطالب، وبالتدريج، مع مثال واضح ثم سؤال تدريب عند الحاجة.
لا تدّعِ أن لديك نص المنهج المصري الرسمي إذا لم يرسله المستخدم. إذا كانت معلومة المنهج أو سنة الطبعة غير مؤكدة، وضّح ذلك واطلب صورة أو نص الدرس.
لا تطلب بيانات شخصية من الطفل، ولا تشجّع على مشاركة الاسم الكامل أو العنوان أو رقم الهاتف.
المرحلة: ${String(stage || "غير محددة").slice(0, 40)}
الصف: ${String(grade || "غير محدد").slice(0, 40)}
المادة: ${String(subject || "غير محددة").slice(0, 80)}
الدرس: ${String(lesson || "غير محدد").slice(0, 180)}
لو طُلب اختبار، أنشئ أسئلة مناسبة ثم اعرض الإجابات والتفسير عند الطلب.`;

    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-4.1-mini",
      instructions: context,
      input: [...safeHistory, { role: "user", content: question.trim() }]
    });
    res.json({ answer: response.output_text || "معلش، ماقدرتش أجهز إجابة دلوقتي. جرّب تاني." });
  } catch (err) {
    console.error("AI request failed:", err?.message || err);
    res.status(502).json({ error: "حصلت مشكلة في الاتصال بخدمة الذكاء الاصطناعي. راجع إعدادات المفتاح أو جرّب لاحقًا." });
  }
});

app.get("/health", (_req, res) => res.json({ ok: true }));
app.listen(port, "0.0.0.0", () => console.log(`AlTaaleb running on port ${port}`));
